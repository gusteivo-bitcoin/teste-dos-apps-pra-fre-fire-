import { ScrollView, Text, View, Pressable, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

export default function AcessibilidadeScreen() {
  const colors = useColors();
  const { accessibilitySettings, setAccessibilitySettings } = useMiraStore();

  const handleToggle = (key: string, value: boolean) => {
    setAccessibilitySettings({ [key]: value });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleSliderChange = (key: string, value: number) => {
    setAccessibilitySettings({ [key]: parseFloat(value.toFixed(2)) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Acessibilidade</Text>
          <Text className="text-sm text-muted mt-1">Otimizações de sistema</Text>
        </View>

        {/* Remover Animações */}
        <View className="px-6 pt-6 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Remover Animações</Text>
                <Text className="text-xs text-muted mt-1">
                  Desativa escalas, transições e animadores
                </Text>
              </View>
              <Switch
                value={accessibilitySettings.removeAnimations}
                onValueChange={(v) => handleToggle("removeAnimations", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={accessibilitySettings.removeAnimations ? colors.warning : colors.muted}
              />
            </View>

            {accessibilitySettings.removeAnimations && (
              <View className="mt-4 pt-4 border-t border-border">
                <View className="flex-row justify-between mb-3">
                  <Text className="text-sm font-semibold text-foreground">Escala de Animação</Text>
                  <Text className="text-sm font-bold text-primary">
                    {(accessibilitySettings.animationScale * 100).toFixed(0)}%
                  </Text>
                </View>
                <Slider
                  style={{ height: 40 }}
                  minimumValue={0}
                  maximumValue={1}
                  step={0.1}
                  value={accessibilitySettings.animationScale}
                  onValueChange={(v) => handleSliderChange("animationScale", v)}
                  minimumTrackTintColor={colors.primary}
                  maximumTrackTintColor={colors.border}
                  thumbTintColor={colors.primary}
                />
                <Text className="text-xs text-muted mt-2">
                  0% = Sem animação (mais rápido) | 100% = Animação normal
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* TalkBack */}
        <View className="px-6 pt-2 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">TalkBack</Text>
                <Text className="text-xs text-muted mt-1">
                  Leitura automática para estabilizar mira
                </Text>
              </View>
              <Switch
                value={accessibilitySettings.talkBackEnabled}
                onValueChange={(v) => handleToggle("talkBackEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={accessibilitySettings.talkBackEnabled ? colors.warning : colors.muted}
              />
            </View>

            {accessibilitySettings.talkBackEnabled && (
              <View className="mt-4 pt-4 border-t border-border">
                <Text className="text-xs text-muted leading-relaxed">
                  ⚠️ O efeito varia conforme o dispositivo. Teste em partidas para validar.
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Switch Access */}
        <View className="px-6 pt-2 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Acesso com Interruptor</Text>
                <Text className="text-xs text-muted mt-1">
                  Controle alternativo de toque
                </Text>
              </View>
              <Switch
                value={accessibilitySettings.switchAccessEnabled}
                onValueChange={(v) => handleToggle("switchAccessEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={accessibilitySettings.switchAccessEnabled ? colors.warning : colors.muted}
              />
            </View>
          </View>
        </View>

        {/* Atraso ao Manter Pressionado */}
        <View className="px-6 pt-2 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row justify-between mb-3">
              <Text className="text-base font-bold text-foreground">Atraso ao Manter Pressionado</Text>
              <Text className="text-sm font-bold text-primary">{accessibilitySettings.longPressDelay.toFixed(1)}s</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={0.5}
              maximumValue={1.0}
              step={0.1}
              value={accessibilitySettings.longPressDelay}
              onValueChange={(v) => handleSliderChange("longPressDelay", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-2">
              Menor atraso = Reconhecimento mais rápido do toque
            </Text>
          </View>
        </View>

        {/* Tamanho de Exibição */}
        <View className="px-6 pt-2 pb-6">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row justify-between mb-3">
              <Text className="text-base font-bold text-foreground">Tamanho de Exibição</Text>
              <Text className="text-sm font-bold text-primary">{accessibilitySettings.displaySize.toFixed(0)}%</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={80}
              maximumValue={120}
              step={5}
              value={accessibilitySettings.displaySize}
              onValueChange={(v) => handleSliderChange("displaySize", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-2">
              Diminuir = Mais campo de visão | Aumentar = Elementos maiores
            </Text>
          </View>
        </View>

        {/* Dicas */}
        <View className="px-6 py-6">
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View className="gap-2">
              <Text className="text-sm font-bold text-warning">⚡ Configuração Recomendada</Text>
              <Text className="text-xs text-muted leading-relaxed">
                • Remover Animações: ATIVADO{"\n"}
                • Escala de Animação: 0%{"\n"}
                • Atraso ao Manter: 0,5s{"\n"}
                • Tamanho de Exibição: 95-100%
              </Text>
            </View>

            <View className="gap-2 pt-3 border-t border-border">
              <Text className="text-sm font-bold text-warning">💡 Dica</Text>
              <Text className="text-xs text-muted leading-relaxed">
                Essas mudanças reduzem o delay visual entre o toque e a ação, tornando a mira mais responsiva.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
