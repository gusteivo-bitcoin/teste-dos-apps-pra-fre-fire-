import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type FingerSleevesType = "fibra-prata" | "algodao" | "nenhum";
type ScreenProtectorType = "vidro" | "plastico" | "nenhum";
type CaseType = "fino" | "medio" | "nenhum";

export default function AcessoriosScreen() {
  const colors = useColors();
  const { accessoriesSettings, setAccessoriesSettings } = useMiraStore();

  const handleFingerSleevesChange = (type: FingerSleevesType) => {
    setAccessoriesSettings({ fingerSleevesType: type });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleScreenProtectorChange = (type: ScreenProtectorType) => {
    setAccessoriesSettings({ screenProtectorType: type });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleCaseChange = (type: CaseType) => {
    setAccessoriesSettings({ caseType: type });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Acessórios</Text>
          <Text className="text-sm text-muted mt-1">Equipamento recomendado</Text>
        </View>

        {/* Luvas de Dedo */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Luvas de Dedo (Finger Sleeves)
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="mb-4">
              <Text className="text-sm font-bold text-foreground mb-2">Por que usar?</Text>
              <Text className="text-xs text-muted leading-relaxed">
                • Reduz atrito do suor no dedo{"\n"}
                • Melhora deslizamento constante{"\n"}
                • Essencial para "puxadinho" perfeito{"\n"}
                • Aumenta precisão da mira
              </Text>
            </View>

            <View className="gap-2">
              {(["fibra-prata", "algodao", "nenhum"] as FingerSleevesType[]).map((type) => {
                const labels = {
                  "fibra-prata": "Fibra de Prata",
                  algodao: "Algodão",
                  nenhum: "Nenhum",
                };

                const descriptions = {
                  "fibra-prata": "Melhor condutividade - RECOMENDADO",
                  algodao: "Bom, mas menos eficiente",
                  nenhum: "Sem proteção",
                };

                return (
                  <Pressable
                    key={type}
                    onPress={() => handleFingerSleevesChange(type)}
                    style={({ pressed }) => [
                      {
                        backgroundColor:
                          accessoriesSettings.fingerSleevesType === type
                            ? colors.primary
                            : colors.surface,
                        borderColor:
                          accessoriesSettings.fingerSleevesType === type
                            ? colors.primary
                            : colors.border,
                        borderWidth: 2,
                        borderRadius: 8,
                        padding: 10,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text
                      className={`text-sm font-bold ${
                        accessoriesSettings.fingerSleevesType === type
                          ? "text-background"
                          : "text-foreground"
                      }`}
                    >
                      {labels[type]}
                    </Text>
                    <Text
                      className={`text-xs mt-1 ${
                        accessoriesSettings.fingerSleevesType === type
                          ? "text-background/80"
                          : "text-muted"
                      }`}
                    >
                      {descriptions[type]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>

        {/* Protetor de Tela */}
        <View className="px-6 pt-2 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Protetor de Tela
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="mb-4">
              <Text className="text-sm font-bold text-foreground mb-2">Impacto na Mira</Text>
              <Text className="text-xs text-muted leading-relaxed">
                • Vidro: Melhor resposta ao toque{"\n"}
                • Plástico: Mais proteção, menos sensibilidade{"\n"}
                • Sem protetor: Máxima sensibilidade (risco)
              </Text>
            </View>

            <View className="gap-2">
              {(["vidro", "plastico", "nenhum"] as ScreenProtectorType[]).map((type) => {
                const labels = {
                  vidro: "Vidro Temperado",
                  plastico: "Plástico",
                  nenhum: "Nenhum",
                };

                const descriptions = {
                  vidro: "Melhor balanço - RECOMENDADO",
                  plastico: "Mais proteção, menos sensibilidade",
                  nenhum: "Sem proteção",
                };

                return (
                  <Pressable
                    key={type}
                    onPress={() => handleScreenProtectorChange(type)}
                    style={({ pressed }) => [
                      {
                        backgroundColor:
                          accessoriesSettings.screenProtectorType === type
                            ? colors.primary
                            : colors.surface,
                        borderColor:
                          accessoriesSettings.screenProtectorType === type
                            ? colors.primary
                            : colors.border,
                        borderWidth: 2,
                        borderRadius: 8,
                        padding: 10,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text
                      className={`text-sm font-bold ${
                        accessoriesSettings.screenProtectorType === type
                          ? "text-background"
                          : "text-foreground"
                      }`}
                    >
                      {labels[type]}
                    </Text>
                    <Text
                      className={`text-xs mt-1 ${
                        accessoriesSettings.screenProtectorType === type
                          ? "text-background/80"
                          : "text-muted"
                      }`}
                    >
                      {descriptions[type]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>

        {/* Case */}
        <View className="px-6 pt-2 pb-6">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Case / Capa
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="mb-4">
              <Text className="text-sm font-bold text-foreground mb-2">Recomendação</Text>
              <Text className="text-xs text-muted leading-relaxed">
                • Fino: Melhor sensibilidade (ideal para FF){"\n"}
                • Médio: Proteção moderada{"\n"}
                • Nenhum: Máxima sensibilidade (risco de queda)
              </Text>
            </View>

            <View className="gap-2">
              {(["fino", "medio", "nenhum"] as CaseType[]).map((type) => {
                const labels = {
                  fino: "Case Fino",
                  medio: "Case Médio",
                  nenhum: "Nenhum",
                };

                const descriptions = {
                  fino: "Proteção mínima, máxima sensibilidade - RECOMENDADO",
                  medio: "Proteção balanceada",
                  nenhum: "Sem proteção",
                };

                return (
                  <Pressable
                    key={type}
                    onPress={() => handleCaseChange(type)}
                    style={({ pressed }) => [
                      {
                        backgroundColor:
                          accessoriesSettings.caseType === type ? colors.primary : colors.surface,
                        borderColor:
                          accessoriesSettings.caseType === type ? colors.primary : colors.border,
                        borderWidth: 2,
                        borderRadius: 8,
                        padding: 10,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text
                      className={`text-sm font-bold ${
                        accessoriesSettings.caseType === type
                          ? "text-background"
                          : "text-foreground"
                      }`}
                    >
                      {labels[type]}
                    </Text>
                    <Text
                      className={`text-xs mt-1 ${
                        accessoriesSettings.caseType === type ? "text-background/80" : "text-muted"
                      }`}
                    >
                      {descriptions[type]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>

        {/* Setup Recomendado */}
        <View className="px-6 py-6">
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View className="gap-2">
              <Text className="text-sm font-bold text-warning">🎯 Setup Recomendado para FF</Text>
              <Text className="text-xs text-muted leading-relaxed">
                <Text className="font-bold">Luvas:</Text> Fibra de Prata{"\n"}
                <Text className="font-bold">Protetor:</Text> Vidro Temperado{"\n"}
                <Text className="font-bold">Case:</Text> Fino{"\n"}
                <Text className="font-bold">Resultado:</Text> Máxima sensibilidade + proteção
              </Text>
            </View>

            <View className="gap-2 pt-3 border-t border-border">
              <Text className="text-sm font-bold text-warning">💡 Dica Final</Text>
              <Text className="text-xs text-muted leading-relaxed">
                A melhor função é a PRÁTICA. Mesmo com o melhor setup, você precisa treinar seu "puxadinho" em partidas reais. Dedique tempo!
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
