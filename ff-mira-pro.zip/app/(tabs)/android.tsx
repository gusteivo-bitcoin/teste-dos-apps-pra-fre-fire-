import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import { useState } from "react";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type TouchResponseType = "long" | "normal" | "short";

export default function AndroidScreen() {
  const colors = useColors();
  const { androidFunctions, setAndroidFunctions } = useMiraStore();

  const handleDPIChange = (value: number) => {
    setAndroidFunctions({ dpiValue: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handlePointerSpeedChange = (value: number) => {
    setAndroidFunctions({ pointerSpeed: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleTouchResponseChange = (type: TouchResponseType) => {
    setAndroidFunctions({ touchResponseTime: type });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const getDPIRisk = (dpi: number) => {
    if (dpi < 350) return { level: "Baixo", color: colors.success, text: "Seguro" };
    if (dpi < 500) return { level: "Médio", color: colors.warning, text: "Recomendado" };
    if (dpi < 700) return { level: "Alto", color: colors.error, text: "Cuidado" };
    return { level: "Crítico", color: colors.error, text: "Risco de Formatar" };
  };

  const riskLevel = getDPIRisk(androidFunctions.dpiValue);

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Funções Android</Text>
          <Text className="text-sm text-muted mt-1">Modo Desenvolvedor</Text>
        </View>

        {/* Aviso de Segurança */}
        <View className="mx-6 mt-6 bg-error/20 border border-error rounded-lg p-4">
          <View className="flex-row gap-3 items-flex-start">
            <MaterialIcons name="warning" size={20} color={colors.error} />
            <View className="flex-1">
              <Text className="text-sm font-bold text-error">⚠️ Aviso Importante</Text>
              <Text className="text-xs text-foreground mt-1 leading-relaxed">
                DPI muito alta pode formatar seu celular. Use com cuidado e sempre faça backup.
              </Text>
            </View>
          </View>
        </View>

        {/* DPI */}
        <View className="px-6 pt-8 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            DPI (Menor Largura)
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row justify-between items-center mb-3">
              <Text className="text-lg font-bold text-foreground">{androidFunctions.dpiValue}</Text>
              <View
                className="px-3 py-1 rounded"
                style={{ backgroundColor: riskLevel.color }}
              >
                <Text className="text-xs font-bold text-background">{riskLevel.text}</Text>
              </View>
            </View>

            <Slider
              style={{ height: 40 }}
              minimumValue={300}
              maximumValue={800}
              step={10}
              value={androidFunctions.dpiValue}
              onValueChange={handleDPIChange}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />

            <View className="mt-3 gap-2">
              <Text className="text-xs text-muted">
                <Text className="font-bold">300-400:</Text> Seguro
              </Text>
              <Text className="text-xs text-muted">
                <Text className="font-bold">400-600:</Text> Recomendado para FF
              </Text>
              <Text className="text-xs text-muted">
                <Text className="font-bold">600+:</Text> Alto risco de dano
              </Text>
            </View>
          </View>
        </View>

        {/* Velocidade do Ponteiro */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Velocidade do Ponteiro
          </Text>

          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Velocidade</Text>
              <Text className="text-sm font-bold text-primary">{androidFunctions.pointerSpeed}/10</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={1}
              maximumValue={10}
              step={1}
              value={androidFunctions.pointerSpeed}
              onValueChange={handlePointerSpeedChange}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-1">Aumenta a resposta ao toque</Text>
          </View>
        </View>

        {/* Tempo de Resposta ao Toque */}
        <View className="px-6 pt-6 pb-6">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Tempo de Resposta ao Toque
          </Text>

          <View className="gap-3">
            {(["long", "normal", "short"] as TouchResponseType[]).map((type) => {
              const labels = {
                long: "Longo",
                normal: "Normal",
                short: "Curto",
              };

              const descriptions = {
                long: "Mais tempo para detectar toque longo",
                normal: "Padrão do sistema",
                short: "Resposta mais rápida (recomendado para FF)",
              };

              return (
                <Pressable
                  key={type}
                  onPress={() => handleTouchResponseChange(type)}
                  style={({ pressed }) => [
                    {
                      backgroundColor:
                        androidFunctions.touchResponseTime === type
                          ? colors.primary
                          : colors.surface,
                      borderColor:
                        androidFunctions.touchResponseTime === type
                          ? colors.primary
                          : colors.border,
                      borderWidth: 2,
                      borderRadius: 8,
                      padding: 12,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text
                    className={`text-sm font-bold ${
                      androidFunctions.touchResponseTime === type
                        ? "text-background"
                        : "text-foreground"
                    }`}
                  >
                    {labels[type]}
                  </Text>
                  <Text
                    className={`text-xs mt-1 ${
                      androidFunctions.touchResponseTime === type
                        ? "text-background/80"
                        : "text-muted"
                    }`}
                  >
                    {descriptions[type]}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Info do Dispositivo */}
        <View className="px-6 pt-6 pb-6">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Informações do Dispositivo
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View className="flex-row justify-between">
              <Text className="text-sm text-muted">Versão Android:</Text>
              <Text className="text-sm font-bold text-foreground">12+</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-sm text-muted">DPI Atual:</Text>
              <Text className="text-sm font-bold text-primary">{androidFunctions.dpiValue}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-sm text-muted">Velocidade Ponteiro:</Text>
              <Text className="text-sm font-bold text-primary">{androidFunctions.pointerSpeed}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-sm text-muted">Resposta Toque:</Text>
              <Text className="text-sm font-bold text-primary">
                {androidFunctions.touchResponseTime === "short"
                  ? "Curto"
                  : androidFunctions.touchResponseTime === "normal"
                    ? "Normal"
                    : "Longo"}
              </Text>
            </View>
          </View>
        </View>

        {/* Save Button */}
        <View className="px-6 py-6">
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                opacity: pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text className="text-base font-bold text-background text-center">
              Salvar Configuração
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
