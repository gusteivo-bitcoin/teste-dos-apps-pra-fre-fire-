import { ScrollView, Text, View, Pressable, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import { useState } from "react";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type WeaponType = "ar" | "smg" | "shotgun" | "sniper" | "franco";

export default function AssistenciasScreen() {
  const colors = useColors();
  const { smartAssistances, setSmartAssistances } = useMiraStore();

  const weapons: { id: WeaponType; label: string; icon: string; desc: string }[] = [
    { id: "ar", label: "AR (Rifle)", icon: "gps-fixed", desc: "Rifle de Assalto" },
    { id: "smg", label: "SMG (Metralhadora)", icon: "gps-fixed", desc: "Metralhadora" },
    { id: "shotgun", label: "Shotgun", icon: "gps-fixed", desc: "Espingarda" },
    { id: "sniper", label: "Sniper", icon: "gps-fixed", desc: "Franco-atirador" },
    { id: "franco", label: "Franco", icon: "gps-fixed", desc: "Rifle de Precisão" },
  ];

  const handleToggle = (key: string, value: boolean) => {
    setSmartAssistances({ [key]: value });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleSliderChange = (key: string, value: number) => {
    setSmartAssistances({ [key]: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleWeaponSelect = (weapon: WeaponType) => {
    setSmartAssistances({ selectedWeapon: weapon });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Assistências Inteligentes</Text>
          <Text className="text-sm text-muted mt-1">Funções para melhorar sua mira</Text>
        </View>

        {/* Grudar Mira na Cabeça */}
        <View className="px-6 pt-6 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Grudar Mira na Cabeça</Text>
                <Text className="text-xs text-muted mt-1">
                  Força a mira a grudar na cabeça do inimigo
                </Text>
              </View>
              <Switch
                value={smartAssistances.headstickEnabled}
                onValueChange={(v) => handleToggle("headstickEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={smartAssistances.headstickEnabled ? colors.warning : colors.muted}
              />
            </View>

            {smartAssistances.headstickEnabled && (
              <View className="mt-4 pt-4 border-t border-border">
                <View className="flex-row justify-between mb-3">
                  <Text className="text-sm font-semibold text-foreground">Força de Grudar</Text>
                  <Text className="text-sm font-bold text-primary">{smartAssistances.headstickStrength}%</Text>
                </View>
                <Slider
                  style={{ height: 40 }}
                  minimumValue={34}
                  maximumValue={100}
                  step={1}
                  value={smartAssistances.headstickStrength}
                  onValueChange={(v) => handleSliderChange("headstickStrength", v)}
                  minimumTrackTintColor={colors.primary}
                  maximumTrackTintColor={colors.border}
                  thumbTintColor={colors.primary}
                />
                <View className="flex-row gap-2 mt-3">
                  {[34, 50, 75, 100].map((val) => (
                    <Pressable
                      key={val}
                      onPress={() => handleSliderChange("headstickStrength", val)}
                      className="flex-1 bg-border rounded px-2 py-2"
                    >
                      <Text className="text-xs font-bold text-foreground text-center">{val}%</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            )}
          </View>
        </View>

        {/* Gelo Rápido */}
        <View className="px-6 pt-2 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Gelo Rápido</Text>
                <Text className="text-xs text-muted mt-1">
                  Congela a sensibilidade temporariamente
                </Text>
              </View>
              <Switch
                value={smartAssistances.iceQuickEnabled}
                onValueChange={(v) => handleToggle("iceQuickEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={smartAssistances.iceQuickEnabled ? colors.warning : colors.muted}
              />
            </View>

            {smartAssistances.iceQuickEnabled && (
              <View className="mt-4 pt-4 border-t border-border">
                <View className="flex-row justify-between mb-3">
                  <Text className="text-sm font-semibold text-foreground">Intensidade</Text>
                  <Text className="text-sm font-bold text-primary">{smartAssistances.iceQuickIntensity}%</Text>
                </View>
                <Slider
                  style={{ height: 40 }}
                  minimumValue={0}
                  maximumValue={100}
                  step={5}
                  value={smartAssistances.iceQuickIntensity}
                  onValueChange={(v) => handleSliderChange("iceQuickIntensity", v)}
                  minimumTrackTintColor={colors.primary}
                  maximumTrackTintColor={colors.border}
                  thumbTintColor={colors.primary}
                />
              </View>
            )}
          </View>
        </View>

        {/* Modo Armas */}
        <View className="px-6 pt-2 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Modo Armas</Text>
                <Text className="text-xs text-muted mt-1">
                  Ativa sensibilidade otimizada por arma
                </Text>
              </View>
              <Switch
                value={smartAssistances.weaponModeEnabled}
                onValueChange={(v) => handleToggle("weaponModeEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={smartAssistances.weaponModeEnabled ? colors.warning : colors.muted}
              />
            </View>

            {smartAssistances.weaponModeEnabled && (
              <View className="mt-4 pt-4 border-t border-border gap-2">
                {weapons.map((weapon) => (
                  <Pressable
                    key={weapon.id}
                    onPress={() => handleWeaponSelect(weapon.id)}
                    style={({ pressed }) => [
                      {
                        backgroundColor:
                          smartAssistances.selectedWeapon === weapon.id
                            ? colors.primary
                            : colors.surface,
                        borderColor:
                          smartAssistances.selectedWeapon === weapon.id
                            ? colors.primary
                            : colors.border,
                        borderWidth: 2,
                        borderRadius: 8,
                        padding: 12,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text
                      className={`text-sm font-bold ${
                        smartAssistances.selectedWeapon === weapon.id
                          ? "text-background"
                          : "text-foreground"
                      }`}
                    >
                      {weapon.label}
                    </Text>
                    <Text
                      className={`text-xs mt-1 ${
                        smartAssistances.selectedWeapon === weapon.id
                          ? "text-background/80"
                          : "text-muted"
                      }`}
                    >
                      {weapon.desc}
                    </Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>
        </View>

        {/* Control Shot */}
        <View className="px-6 pt-2 pb-6">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Control Shot</Text>
                <Text className="text-xs text-muted mt-1">
                  Técnica de "puxadinho" com mira padrão
                </Text>
              </View>
              <Switch
                value={smartAssistances.controlShotEnabled}
                onValueChange={(v) => handleToggle("controlShotEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={smartAssistances.controlShotEnabled ? colors.warning : colors.muted}
              />
            </View>

            {smartAssistances.controlShotEnabled && (
              <View className="mt-4 pt-4 border-t border-border gap-2">
                <Text className="text-xs font-bold text-warning">📌 Como Usar:</Text>
                <Text className="text-xs text-muted leading-relaxed">
                  1. Posicione a mira na altura do peito{"\n"}
                  2. Puxe suavemente para cima até a cabeça{"\n"}
                  3. Dispare quando a mira estiver na cabeça{"\n"}
                  4. Pratique o timing para dominar
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Resumo de Assistências Ativas */}
        <View className="px-6 py-6">
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-sm font-bold text-foreground mb-3">Assistências Ativas</Text>
            <View className="gap-2">
              {smartAssistances.headstickEnabled && (
                <View className="flex-row items-center gap-2">
                  <View className="w-2 h-2 rounded-full bg-success" />
                  <Text className="text-xs text-muted">
                    Grudar Mira ({smartAssistances.headstickStrength}%)
                  </Text>
                </View>
              )}
              {smartAssistances.iceQuickEnabled && (
                <View className="flex-row items-center gap-2">
                  <View className="w-2 h-2 rounded-full bg-success" />
                  <Text className="text-xs text-muted">
                    Gelo Rápido ({smartAssistances.iceQuickIntensity}%)
                  </Text>
                </View>
              )}
              {smartAssistances.weaponModeEnabled && (
                <View className="flex-row items-center gap-2">
                  <View className="w-2 h-2 rounded-full bg-success" />
                  <Text className="text-xs text-muted">
                    Modo {smartAssistances.selectedWeapon.toUpperCase()}
                  </Text>
                </View>
              )}
              {smartAssistances.controlShotEnabled && (
                <View className="flex-row items-center gap-2">
                  <View className="w-2 h-2 rounded-full bg-success" />
                  <Text className="text-xs text-muted">Control Shot</Text>
                </View>
              )}
              {!smartAssistances.headstickEnabled &&
                !smartAssistances.iceQuickEnabled &&
                !smartAssistances.weaponModeEnabled &&
                !smartAssistances.controlShotEnabled && (
                  <Text className="text-xs text-muted italic">Nenhuma assistência ativa</Text>
                )}
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
