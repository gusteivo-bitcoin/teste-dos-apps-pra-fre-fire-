import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type MiraTypeType = "novo" | "classico";
type VisualEffectType = "normal" | "sem-sangue" | "escuro";

export default function HUDScreen() {
  const colors = useColors();
  const { hudSettings, setHUDSettings } = useMiraStore();

  const handleMiraTypeChange = (type: MiraTypeType) => {
    setHUDSettings({ miraType: type });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleVisualEffectChange = (effect: VisualEffectType) => {
    setHUDSettings({ visualEffect: effect });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleSliderChange = (key: string, value: number) => {
    setHUDSettings({ [key]: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleColorChange = (color: string) => {
    setHUDSettings({ crosshairColor: color });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">HUD & Mira</Text>
          <Text className="text-sm text-muted mt-1">Ajustes visuais do jogo</Text>
        </View>

        {/* Tipo de Mira */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Tipo de Mira
          </Text>

          <View className="gap-3 mb-4">
            {(["novo", "classico"] as MiraTypeType[]).map((type) => {
              const labels = {
                novo: "Novo",
                classico: "Clássico",
              };

              const descriptions = {
                novo: "Recuo visual mais suave e responsivo",
                classico: "Recuo visual tradicional",
              };

              return (
                <Pressable
                  key={type}
                  onPress={() => handleMiraTypeChange(type)}
                  style={({ pressed }) => [
                    {
                      backgroundColor:
                        hudSettings.miraType === type ? colors.primary : colors.surface,
                      borderColor:
                        hudSettings.miraType === type ? colors.primary : colors.border,
                      borderWidth: 2,
                      borderRadius: 8,
                      padding: 12,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text
                    className={`text-base font-bold ${
                      hudSettings.miraType === type ? "text-background" : "text-foreground"
                    }`}
                  >
                    {labels[type]}
                  </Text>
                  <Text
                    className={`text-xs mt-1 ${
                      hudSettings.miraType === type ? "text-background/80" : "text-muted"
                    }`}
                  >
                    {descriptions[type]}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Efeito Visual */}
        <View className="px-6 pt-2 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Efeito Visual
          </Text>

          <View className="gap-3 mb-4">
            {(["normal", "sem-sangue", "escuro"] as VisualEffectType[]).map((effect) => {
              const labels = {
                normal: "Normal",
                "sem-sangue": "Sem Sangue",
                escuro: "Escuro",
              };

              const descriptions = {
                normal: "Visão padrão com efeitos",
                "sem-sangue": "Remove sangue - visão mais limpa",
                escuro: "Modo escuro - melhor contraste",
              };

              return (
                <Pressable
                  key={effect}
                  onPress={() => handleVisualEffectChange(effect)}
                  style={({ pressed }) => [
                    {
                      backgroundColor:
                        hudSettings.visualEffect === effect ? colors.primary : colors.surface,
                      borderColor:
                        hudSettings.visualEffect === effect ? colors.primary : colors.border,
                      borderWidth: 2,
                      borderRadius: 8,
                      padding: 12,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text
                    className={`text-base font-bold ${
                      hudSettings.visualEffect === effect ? "text-background" : "text-foreground"
                    }`}
                  >
                    {labels[effect]}
                  </Text>
                  <Text
                    className={`text-xs mt-1 ${
                      hudSettings.visualEffect === effect ? "text-background/80" : "text-muted"
                    }`}
                  >
                    {descriptions[effect]}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Custom Crosshair */}
        <View className="px-6 pt-2 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Crosshair Customizado
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            {/* Preview */}
            <View className="bg-black rounded-lg p-8 mb-4 items-center justify-center" style={{ height: 150 }}>
              <View
                style={{
                  width: hudSettings.crosshairSize * 2,
                  height: hudSettings.crosshairSize * 2,
                  borderRadius: hudSettings.crosshairSize,
                  backgroundColor: hudSettings.crosshairColor,
                  opacity: hudSettings.crosshairOpacity / 100,
                }}
              />
            </View>

            {/* Tamanho */}
            <View className="mb-4">
              <View className="flex-row justify-between mb-2">
                <Text className="text-sm font-semibold text-foreground">Tamanho</Text>
                <Text className="text-sm font-bold text-primary">{hudSettings.crosshairSize}px</Text>
              </View>
              <Slider
                style={{ height: 40 }}
                minimumValue={5}
                maximumValue={30}
                step={1}
                value={hudSettings.crosshairSize}
                onValueChange={(v) => handleSliderChange("crosshairSize", v)}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                thumbTintColor={colors.primary}
              />
            </View>

            {/* Opacidade */}
            <View className="mb-4">
              <View className="flex-row justify-between mb-2">
                <Text className="text-sm font-semibold text-foreground">Opacidade</Text>
                <Text className="text-sm font-bold text-primary">{hudSettings.crosshairOpacity}%</Text>
              </View>
              <Slider
                style={{ height: 40 }}
                minimumValue={0}
                maximumValue={100}
                step={10}
                value={hudSettings.crosshairOpacity}
                onValueChange={(v) => handleSliderChange("crosshairOpacity", v)}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                thumbTintColor={colors.primary}
              />
            </View>

            {/* Cores */}
            <View className="mb-2">
              <Text className="text-sm font-semibold text-foreground mb-3">Cor</Text>
              <View className="flex-row gap-2 flex-wrap">
                {["#FFD700", "#FF6B00", "#00FF00", "#00FFFF", "#FF00FF", "#FFFFFF"].map((color) => (
                  <Pressable
                    key={color}
                    onPress={() => handleColorChange(color)}
                    style={({ pressed }) => [
                      {
                        width: 40,
                        height: 40,
                        borderRadius: 20,
                        backgroundColor: color,
                        borderWidth: hudSettings.crosshairColor === color ? 3 : 1,
                        borderColor:
                          hudSettings.crosshairColor === color ? colors.foreground : colors.border,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  />
                ))}
              </View>
            </View>
          </View>
        </View>

        {/* Dicas */}
        <View className="px-6 py-6">
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View className="gap-2">
              <Text className="text-sm font-bold text-warning">💡 Dica de Pré-Posicionamento</Text>
              <Text className="text-xs text-muted leading-relaxed">
                Use o crosshair customizado para pré-posicionar a mira na altura da cabeça antes de abrir o zoom. Isso melhora o tempo de reação.
              </Text>
            </View>

            <View className="gap-2 pt-3 border-t border-border">
              <Text className="text-sm font-bold text-warning">⚡ Recomendação</Text>
              <Text className="text-xs text-muted leading-relaxed">
                • Tipo de Mira: Novo{"\n"}
                • Efeito Visual: Sem Sangue{"\n"}
                • Crosshair: Amarelo, 15px, 80% opacidade
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
