import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import { useRouter, Href } from "expo-router";
import * as Haptics from "expo-haptics";

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { activeProfile, miraSettings } = useMiraStore();

  const tips = [
    {
      title: "Dica #1: Sensibilidade Baixa",
      desc: "Use sensibilidade baixa para melhor controle em distâncias longas",
    },
    {
      title: "Dica #2: Mira Pequena",
      desc: "Miras menores ajudam a mirar em alvos pequenos e distantes",
    },
    {
      title: "Dica #3: Perfis por Arma",
      desc: "Crie perfis diferentes para cada arma (AR, Sniper, Shotgun)",
    },
    {
      title: "Dica #4: Teste Sempre",
      desc: "Teste suas configurações em partidas antes de usar em ranked",
    },
  ];

  const handleNavigateToMira = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push("mira" as Href);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary mb-1">FF Mira Pro</Text>
          <Text className="text-sm text-muted">Otimize sua mira para Free Fire</Text>
        </View>

        {/* Active Profile Card */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-3">
            Perfil Ativo
          </Text>
          <Pressable
            onPress={handleNavigateToMira}
            style={({ pressed }) => [
              {
                backgroundColor: colors.surface,
                borderColor: colors.primary,
                borderWidth: 2,
                borderRadius: 12,
                padding: 16,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            <Text className="text-lg font-bold text-primary mb-2">
              {activeProfile || "Padrão"}
            </Text>
            <View className="gap-2">
              <View className="flex-row justify-between">
                <Text className="text-xs text-muted">Tamanho da Mira:</Text>
                <Text className="text-sm font-semibold text-foreground">
                  {miraSettings.size}/10
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-xs text-muted">Cor da Mira:</Text>
                <View
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: miraSettings.color }}
                />
              </View>
            </View>
          </Pressable>
        </View>

        {/* Quick Access */}
        <View className="px-6 pt-6 pb-2">
          <TouchableOpacity
            onPress={handleNavigateToMira}
            activeOpacity={0.7}
            className="bg-primary rounded-lg py-3 px-4 flex-row items-center justify-center gap-2"
          >
            <Text className="text-base font-bold text-background">Ajustar Mira Agora</Text>
          </TouchableOpacity>
        </View>

        {/* Tips Section */}
        <View className="px-6 pt-8 pb-6">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Dicas de Mira
          </Text>
          <View className="gap-3">
            {tips.map((tip, idx) => (
              <View
                key={idx}
                className="bg-surface rounded-lg p-4 border border-border"
              >
                <Text className="text-sm font-bold text-warning mb-1">{tip.title}</Text>
                <Text className="text-xs text-muted leading-relaxed">{tip.desc}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Footer Info */}
        <View className="px-6 py-4 border-t border-border">
          <Text className="text-xs text-muted text-center">
            Versão 1.0.0 • Otimizado para Free Fire
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
