import { ScrollView, Text, View, Pressable, Dimensions } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import * as Haptics from "expo-haptics";

export default function InGameScreen() {
  const colors = useColors();
  const { inGameSettings, setInGameSettings } = useMiraStore();
  const screenWidth = Dimensions.get("window").width;

  const handleSliderChange = (key: keyof typeof inGameSettings, value: number) => {
    setInGameSettings({ [key]: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const buttonSize = (inGameSettings.shootButtonSize / 100) * 80;
  const buttonPositionY = (inGameSettings.shootButtonPosition / 100) * 150;

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Configurações In-Game</Text>
          <Text className="text-sm text-muted mt-1">Ajustes dentro do Free Fire</Text>
        </View>

        {/* Simulador Visual */}
        <View className="px-6 pt-8 pb-4">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Simulador de Tela
          </Text>
          <View
            className="bg-black rounded-lg border border-border relative"
            style={{
              width: screenWidth - 48,
              height: 300,
              justifyContent: "flex-end",
              alignItems: "flex-end",
              paddingRight: 16,
              paddingBottom: 16,
            }}
          >
            {/* Botão de Atirar Simulado */}
            <Pressable
              style={{
                width: buttonSize,
                height: buttonSize,
                backgroundColor: colors.primary,
                borderRadius: buttonSize / 2,
                opacity: 0.8,
                marginBottom: buttonPositionY,
              }}
            >
              <Text className="text-xs font-bold text-background text-center" style={{ lineHeight: buttonSize }}>
                Atirar
              </Text>
            </Pressable>

            {/* Info no simulador */}
            <Text
              className="absolute text-xs text-muted"
              style={{ top: 8, left: 8 }}
            >
              Tamanho: {inGameSettings.shootButtonSize}%
            </Text>
          </View>
        </View>

        {/* Sliders */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Sensibilidade
          </Text>

          {/* Sensibilidade Geral */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Sensibilidade Geral</Text>
              <Text className="text-sm font-bold text-primary">{inGameSettings.generalSensitivity}</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={90}
              maximumValue={100}
              step={1}
              value={inGameSettings.generalSensitivity}
              onValueChange={(v) => handleSliderChange("generalSensitivity", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-1">Recomendado: 90-100</Text>
          </View>

          {/* Mira 2x */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Mira 2x</Text>
              <Text className="text-sm font-bold text-primary">{inGameSettings.scope2xSensitivity}</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={90}
              maximumValue={100}
              step={1}
              value={inGameSettings.scope2xSensitivity}
              onValueChange={(v) => handleSliderChange("scope2xSensitivity", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-1">Ajuda a subir a mira mais rápido</Text>
          </View>

          {/* Mira 4x */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Mira 4x</Text>
              <Text className="text-sm font-bold text-primary">{inGameSettings.scope4xSensitivity}</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={85}
              maximumValue={100}
              step={1}
              value={inGameSettings.scope4xSensitivity}
              onValueChange={(v) => handleSliderChange("scope4xSensitivity", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-1">Recomendado: 85-95</Text>
          </View>
        </View>

        {/* Botão de Atirar */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Botão de Atirar
          </Text>

          {/* Tamanho */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Tamanho</Text>
              <Text className="text-sm font-bold text-primary">{inGameSettings.shootButtonSize}%</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={40}
              maximumValue={55}
              step={1}
              value={inGameSettings.shootButtonSize}
              onValueChange={(v) => handleSliderChange("shootButtonSize", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-1">Diminuir dá mais espaço para arrastar</Text>
          </View>

          {/* Posicionamento */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Posicionamento Vertical</Text>
              <Text className="text-sm font-bold text-primary">{inGameSettings.shootButtonPosition}%</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={0}
              maximumValue={100}
              step={5}
              value={inGameSettings.shootButtonPosition}
              onValueChange={(v) => handleSliderChange("shootButtonPosition", v)}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
            <Text className="text-xs text-muted mt-1">0% = Topo | 100% = Fundo</Text>
          </View>
        </View>

        {/* Dicas */}
        <View className="px-6 pt-6 pb-6">
          <View className="bg-surface rounded-lg p-4 border border-border gap-2">
            <Text className="text-sm font-bold text-warning">💡 Dica de Ouro</Text>
            <Text className="text-xs text-muted leading-relaxed">
              Botão menor (40-45%) + Posicionamento baixo (70-80%) = Mais espaço para "puxadinho" rápido
            </Text>
          </View>
        </View>

        {/* Save Button */}
        <View className="px-6 py-6">
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                opacity: pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text className="text-base font-bold text-background text-center">
              Salvar Configuração
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
