import { ScrollView, Text, View, Pressable, Dimensions } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import { Svg, Circle, Line } from "react-native-svg";
import * as Haptics from "expo-haptics";

const colors_list = ["#FF6B00", "#FFD700", "#30D158", "#00B4D8", "#FFFFFF"];

export default function MiraScreen() {
  const colors = useColors();
  const { miraSettings, setMiraSettings } = useMiraStore();
  const screenWidth = Dimensions.get("window").width;
  const previewSize = 200;

  const handleSizeChange = (value: number) => {
    setMiraSettings({ size: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleThicknessChange = (value: number) => {
    setMiraSettings({ thickness: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleGapChange = (value: number) => {
    setMiraSettings({ gap: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleColorChange = (color: string) => {
    setMiraSettings({ color });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const centerX = previewSize / 2;
  const centerY = previewSize / 2;
  const radius = (previewSize / 2) * 0.3;
  const thickness = miraSettings.thickness;
  const gap = miraSettings.gap;

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Ajuste de Mira</Text>
          <Text className="text-sm text-muted mt-1">Customize sua mira para Free Fire</Text>
        </View>

        {/* Preview */}
        <View className="px-6 pt-8 pb-4 items-center">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Preview
          </Text>
          <View
            className="bg-black rounded-lg border border-border items-center justify-center"
            style={{ width: previewSize, height: previewSize }}
          >
            <Svg width={previewSize} height={previewSize}>
              {/* Vertical line top */}
              <Line
                x1={centerX}
                y1={centerY - radius - gap}
                x2={centerX}
                y2={centerY - radius - gap - 30}
                stroke={miraSettings.color}
                strokeWidth={thickness}
              />
              {/* Vertical line bottom */}
              <Line
                x1={centerX}
                y1={centerY + radius + gap}
                x2={centerX}
                y2={centerY + radius + gap + 30}
                stroke={miraSettings.color}
                strokeWidth={thickness}
              />
              {/* Horizontal line left */}
              <Line
                x1={centerX - radius - gap}
                y1={centerY}
                x2={centerX - radius - gap - 30}
                y2={centerY}
                stroke={miraSettings.color}
                strokeWidth={thickness}
              />
              {/* Horizontal line right */}
              <Line
                x1={centerX + radius + gap}
                y1={centerY}
                x2={centerX + radius + gap + 30}
                y2={centerY}
                stroke={miraSettings.color}
                strokeWidth={thickness}
              />
              {/* Circle */}
              <Circle
                cx={centerX}
                cy={centerY}
                r={radius}
                stroke={miraSettings.color}
                strokeWidth={thickness}
                fill="none"
              />
              {/* Center dot */}
              <Circle
                cx={centerX}
                cy={centerY}
                r={thickness * 1.5}
                fill={miraSettings.color}
              />
            </Svg>
          </View>
        </View>

        {/* Sliders */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Configurações
          </Text>

          {/* Size Slider */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Tamanho da Mira</Text>
              <Text className="text-sm font-bold text-primary">{miraSettings.size}/10</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={1}
              maximumValue={10}
              step={1}
              value={miraSettings.size}
              onValueChange={handleSizeChange}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
          </View>

          {/* Thickness Slider */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Espessura das Linhas</Text>
              <Text className="text-sm font-bold text-primary">{miraSettings.thickness}/5</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={1}
              maximumValue={5}
              step={1}
              value={miraSettings.thickness}
              onValueChange={handleThicknessChange}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
          </View>

          {/* Gap Slider */}
          <View className="mb-6">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Gap Central</Text>
              <Text className="text-sm font-bold text-primary">{miraSettings.gap}/10</Text>
            </View>
            <Slider
              style={{ height: 40 }}
              minimumValue={0}
              maximumValue={10}
              step={1}
              value={miraSettings.gap}
              onValueChange={handleGapChange}
              minimumTrackTintColor={colors.primary}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.primary}
            />
          </View>

          {/* Color Picker */}
          <View className="mb-6">
            <Text className="text-sm font-semibold text-foreground mb-3">Cor da Mira</Text>
            <View className="flex-row gap-3 justify-between">
              {colors_list.map((color) => (
                <Pressable
                  key={color}
                  onPress={() => handleColorChange(color)}
                  style={({ pressed }) => [
                    {
                      width: 50,
                      height: 50,
                      borderRadius: 8,
                      backgroundColor: color,
                      borderWidth: miraSettings.color === color ? 3 : 2,
                      borderColor: miraSettings.color === color ? colors.warning : colors.border,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                />
              ))}
            </View>
          </View>
        </View>

        {/* Save Button */}
        <View className="px-6 py-6">
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                opacity: pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text className="text-base font-bold text-background text-center">
              Salvar Configuração
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
