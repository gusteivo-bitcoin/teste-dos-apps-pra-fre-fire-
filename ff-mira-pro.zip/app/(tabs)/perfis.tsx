import {
  ScrollView,
  Text,
  View,
  Pressable,
  FlatList,
  Modal,
  TextInput,
  Alert,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import { useState } from "react";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

export default function PerfisScreen() {
  const colors = useColors();
  const {
    profiles,
    activeProfile,
    createProfile,
    loadProfile,
    deleteProfile,
  } = useMiraStore();
  const [modalVisible, setModalVisible] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");

  const handleCreateProfile = () => {
    if (newProfileName.trim()) {
      createProfile(newProfileName);
      setNewProfileName("");
      setModalVisible(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleLoadProfile = (profileId: string) => {
    loadProfile(profileId);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleDeleteProfile = (profileId: string, profileName: string) => {
    Alert.alert(
      "Deletar Perfil",
      `Tem certeza que deseja deletar "${profileName}"?`,
      [
        { text: "Cancelar", onPress: () => {} },
        {
          text: "Deletar",
          onPress: () => {
            deleteProfile(profileId);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
          style: "destructive",
        },
      ]
    );
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
    });
  };

  return (
    <ScreenContainer className="p-0">
      <View className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Meus Perfis</Text>
          <Text className="text-sm text-muted mt-1">
            {profiles.length} perfil{profiles.length !== 1 ? "s" : ""} salvado
            {profiles.length !== 1 ? "s" : ""}
          </Text>
        </View>

        {/* List or Empty State */}
        {profiles.length === 0 ? (
          <View className="flex-1 items-center justify-center px-6">
            <MaterialIcons
              name="folder-open"
              size={64}
              color={colors.muted}
              style={{ marginBottom: 16 }}
            />
            <Text className="text-lg font-semibold text-foreground text-center mb-2">
              Nenhum Perfil Salvo
            </Text>
            <Text className="text-sm text-muted text-center">
              Crie seu primeiro perfil para salvar suas configurações
            </Text>
          </View>
        ) : (
          <FlatList
            data={profiles}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ padding: 16, gap: 12 }}
            renderItem={({ item }) => (
              <View
                className="bg-surface rounded-lg border p-4"
                style={{
                  borderColor:
                    activeProfile === item.id ? colors.primary : colors.border,
                  borderWidth: activeProfile === item.id ? 2 : 1,
                }}
              >
                <View className="flex-row items-center justify-between mb-3">
                  <View className="flex-1">
                    <Text className="text-base font-bold text-foreground">
                      {item.name}
                    </Text>
                    <Text className="text-xs text-muted mt-1">
                      Criado em {formatDate(item.createdAt)}
                    </Text>
                  </View>
                  {activeProfile === item.id && (
                    <View className="bg-primary px-2 py-1 rounded">
                      <Text className="text-xs font-bold text-background">
                        Ativo
                      </Text>
                    </View>
                  )}
                </View>

                {/* Profile Details */}
                <View className="bg-black/20 rounded p-3 mb-3 gap-1">
                  <Text className="text-xs text-muted">
                    Mira: {item.mira.size}/10 • Cor:{" "}
                    <Text
                      style={{ color: item.mira.color }}
                      className="font-bold"
                    >
                      ■
                    </Text>
                  </Text>
                  <Text className="text-xs text-muted">
                    Sensibilidade: Geral {item.sensibilidade.general} • Mira{" "}
                    {item.sensibilidade.aim}
                  </Text>
                </View>

                {/* Buttons */}
                <View className="flex-row gap-2">
                  <Pressable
                    onPress={() => handleLoadProfile(item.id)}
                    style={({ pressed }) => [
                      {
                        flex: 1,
                        backgroundColor: colors.primary,
                        borderRadius: 8,
                        padding: 10,
                        opacity: pressed ? 0.9 : 1,
                      },
                    ]}
                  >
                    <Text className="text-sm font-bold text-background text-center">
                      Carregar
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={() => handleDeleteProfile(item.id, item.name)}
                    style={({ pressed }) => [
                      {
                        backgroundColor: colors.error,
                        borderRadius: 8,
                        padding: 10,
                        opacity: pressed ? 0.9 : 1,
                      },
                    ]}
                  >
                    <MaterialIcons
                      name="delete"
                      size={20}
                      color={colors.background}
                    />
                  </Pressable>
                </View>
              </View>
            )}
          />
        )}

        {/* New Profile Button */}
        <View className="px-6 py-6 border-t border-border">
          <Pressable
            onPress={() => {
              setModalVisible(true);
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                opacity: pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text className="text-base font-bold text-background text-center">
              + Novo Perfil
            </Text>
          </Pressable>
        </View>

        {/* Modal - Create Profile */}
        <Modal
          animationType="fade"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View
            className="flex-1 items-center justify-center"
            style={{ backgroundColor: "rgba(0, 0, 0, 0.7)" }}
          >
            <View
              className="bg-surface rounded-lg p-6 w-80 border border-border"
              style={{ gap: 16 }}
            >
              <Text className="text-lg font-bold text-foreground">
                Novo Perfil
              </Text>
              <TextInput
                placeholder="Nome do perfil"
                placeholderTextColor={colors.muted}
                value={newProfileName}
                onChangeText={setNewProfileName}
                className="bg-black/20 text-foreground px-4 py-3 rounded-lg border border-border"
                style={{ color: colors.foreground }}
              />
              <View className="flex-row gap-3">
                <Pressable
                  onPress={() => {
                    setModalVisible(false);
                    setNewProfileName("");
                  }}
                  style={({ pressed }) => [
                    {
                      flex: 1,
                      backgroundColor: colors.border,
                      borderRadius: 8,
                      padding: 12,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text className="text-sm font-bold text-foreground text-center">
                    Cancelar
                  </Text>
                </Pressable>
                <Pressable
                  onPress={handleCreateProfile}
                  style={({ pressed }) => [
                    {
                      flex: 1,
                      backgroundColor: colors.primary,
                      borderRadius: 8,
                      padding: 12,
                      opacity: pressed ? 0.9 : 1,
                    },
                  ]}
                >
                  <Text className="text-sm font-bold text-background text-center">
                    Criar
                  </Text>
                </Pressable>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </ScreenContainer>
  );
}
