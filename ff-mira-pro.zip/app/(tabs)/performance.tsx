import { ScrollView, Text, View, Pressable, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type RefreshRateType = "60" | "90" | "120";

export default function PerformanceScreen() {
  const colors = useColors();
  const { performanceSettings, setPerformanceSettings } = useMiraStore();

  const handleToggle = (key: string, value: boolean) => {
    setPerformanceSettings({ [key]: value });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleRefreshRateChange = (rate: RefreshRateType) => {
    setPerformanceSettings({ refreshRate: rate });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Performance</Text>
          <Text className="text-sm text-muted mt-1">Otimizações de tela e sistema</Text>
        </View>

        {/* Taxa de Atualização */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Taxa de Atualização (Hz)
          </Text>

          <View className="gap-3 mb-4">
            {(["60", "90", "120"] as RefreshRateType[]).map((rate) => {
              const descriptions = {
                "60": "Padrão - Menor consumo de bateria",
                "90": "Recomendado - Movimento fluido",
                "120": "Máximo - Mais responsivo (mais bateria)",
              };

              return (
                <Pressable
                  key={rate}
                  onPress={() => handleRefreshRateChange(rate)}
                  style={({ pressed }) => [
                    {
                      backgroundColor:
                        performanceSettings.refreshRate === rate
                          ? colors.primary
                          : colors.surface,
                      borderColor:
                        performanceSettings.refreshRate === rate
                          ? colors.primary
                          : colors.border,
                      borderWidth: 2,
                      borderRadius: 8,
                      padding: 12,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text
                    className={`text-base font-bold ${
                      performanceSettings.refreshRate === rate
                        ? "text-background"
                        : "text-foreground"
                    }`}
                  >
                    {rate} Hz
                  </Text>
                  <Text
                    className={`text-xs mt-1 ${
                      performanceSettings.refreshRate === rate
                        ? "text-background/80"
                        : "text-muted"
                    }`}
                  >
                    {descriptions[rate]}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <View className="bg-surface rounded-lg p-3 border border-border">
            <Text className="text-xs text-muted leading-relaxed">
              💡 <Text className="font-bold">Dica:</Text> 90Hz é o melhor balanço entre fluidez e bateria. 120Hz é ideal se seu celular suporta.
            </Text>
          </View>
        </View>

        {/* Game Turbo */}
        <View className="px-6 pt-6 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Modo Jogo / Game Turbo</Text>
                <Text className="text-xs text-muted mt-1">
                  Prioriza largura de banda e processamento
                </Text>
              </View>
              <Switch
                value={performanceSettings.gameTurboEnabled}
                onValueChange={(v) => handleToggle("gameTurboEnabled", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={performanceSettings.gameTurboEnabled ? colors.warning : colors.muted}
              />
            </View>

            {performanceSettings.gameTurboEnabled && (
              <View className="mt-4 pt-4 border-t border-border gap-2">
                <Text className="text-xs font-bold text-success">✓ Ativado</Text>
                <Text className="text-xs text-muted leading-relaxed">
                  Reduz quedas de FPS que fazem a mira "tremer". Funciona em Xiaomi, Samsung, Motorola, etc.
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Desativar Toque Acidental */}
        <View className="px-6 pt-2 pb-2">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Desativar Proteção de Toque</Text>
                <Text className="text-xs text-muted mt-1">
                  Remove proteção contra toques acidentais
                </Text>
              </View>
              <Switch
                value={performanceSettings.disableAccidentalTouch}
                onValueChange={(v) => handleToggle("disableAccidentalTouch", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={performanceSettings.disableAccidentalTouch ? colors.warning : colors.muted}
              />
            </View>

            {performanceSettings.disableAccidentalTouch && (
              <View className="mt-4 pt-4 border-t border-border gap-2">
                <Text className="text-xs font-bold text-success">✓ Ativado</Text>
                <Text className="text-xs text-muted leading-relaxed">
                  Todos os comandos de puxar a mira nas bordas serão registrados sem bloqueio.
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Priorizar Gaming */}
        <View className="px-6 pt-2 pb-6">
          <View className="bg-surface rounded-lg p-4 border border-border mb-4">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">Priorizar Gaming</Text>
                <Text className="text-xs text-muted mt-1">
                  Desativa notificações e otimiza recursos
                </Text>
              </View>
              <Switch
                value={performanceSettings.prioritizeGaming}
                onValueChange={(v) => handleToggle("prioritizeGaming", v)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={performanceSettings.prioritizeGaming ? colors.warning : colors.muted}
              />
            </View>

            {performanceSettings.prioritizeGaming && (
              <View className="mt-4 pt-4 border-t border-border gap-2">
                <Text className="text-xs font-bold text-success">✓ Ativado</Text>
                <Text className="text-xs text-muted leading-relaxed">
                  Silencia notificações, desativa sincronização em background e libera RAM.
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Resumo */}
        <View className="px-6 py-6">
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <Text className="text-sm font-bold text-foreground mb-2">Configuração Recomendada</Text>
            <View className="gap-2">
              <View className="flex-row items-center gap-2">
                <View
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: performanceSettings.refreshRate === "90" ? colors.success : colors.muted }}
                />
                <Text className="text-xs text-muted">Taxa de Atualização: 90Hz</Text>
              </View>
              <View className="flex-row items-center gap-2">
                <View
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: performanceSettings.gameTurboEnabled ? colors.success : colors.muted }}
                />
                <Text className="text-xs text-muted">Game Turbo: Ativado</Text>
              </View>
              <View className="flex-row items-center gap-2">
                <View
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: performanceSettings.disableAccidentalTouch ? colors.success : colors.muted }}
                />
                <Text className="text-xs text-muted">Toque Acidental: Desativado</Text>
              </View>
              <View className="flex-row items-center gap-2">
                <View
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: performanceSettings.prioritizeGaming ? colors.success : colors.muted }}
                />
                <Text className="text-xs text-muted">Priorizar Gaming: Ativado</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
