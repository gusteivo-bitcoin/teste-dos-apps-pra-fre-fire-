import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import * as Device from "expo-device";
import * as Haptics from "expo-haptics";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

interface DevicePreset {
  pattern: RegExp;
  name: string;
  recommendedDPI: number;
  recommendedSensitivity: number;
  shootButtonSize: number;
  tips: string[];
}

const devicePresets: DevicePreset[] = [
  {
    pattern: /xiaomi|redmi|poco/i,
    name: "Xiaomi/Redmi",
    recommendedDPI: 480,
    recommendedSensitivity: 95,
    shootButtonSize: 45,
    tips: [
      "DPI 450-500 funciona bem",
      "Sensibilidade geral 90-95",
      "Botão de atirar 45-50%",
    ],
  },
  {
    pattern: /samsung|galaxy/i,
    name: "Samsung Galaxy",
    recommendedDPI: 420,
    recommendedSensitivity: 92,
    shootButtonSize: 48,
    tips: [
      "DPI 400-450 recomendado",
      "Sensibilidade 85-92",
      "Toque rápido funciona bem",
    ],
  },
  {
    pattern: /motorola|moto/i,
    name: "Motorola",
    recommendedDPI: 450,
    recommendedSensitivity: 93,
    shootButtonSize: 47,
    tips: [
      "DPI 450-480 ideal",
      "Sensibilidade 90-95",
      "Resposta ao toque curta",
    ],
  },
  {
    pattern: /realme/i,
    name: "Realme",
    recommendedDPI: 500,
    recommendedSensitivity: 96,
    shootButtonSize: 44,
    tips: [
      "DPI 480-520 recomendado",
      "Sensibilidade alta 95-100",
      "Processador rápido = DPI maior",
    ],
  },
  {
    pattern: /iphone|apple/i,
    name: "iPhone",
    recommendedDPI: 460,
    recommendedSensitivity: 94,
    shootButtonSize: 46,
    tips: [
      "DPI 450-480 recomendado",
      "Sensibilidade 90-95",
      "iOS tem resposta mais rápida",
    ],
  },
];

export default function RecomendacoesScreen() {
  const colors = useColors();
  const {
    inGameSettings,
    androidFunctions,
    setInGameSettings,
    setAndroidFunctions,
  } = useMiraStore();

  const deviceModel = Device.modelName || "Desconhecido";
  const getDevicePreset = (): DevicePreset | null => {
    return devicePresets.find((preset) => preset.pattern.test(deviceModel)) || null;
  };

  const preset = getDevicePreset();

  const applyPreset = () => {
    if (preset) {
      setAndroidFunctions({
        dpiValue: preset.recommendedDPI,
      });
      setInGameSettings({
        generalSensitivity: preset.recommendedSensitivity,
        scope2xSensitivity: preset.recommendedSensitivity,
        scope4xSensitivity: preset.recommendedSensitivity - 3,
        shootButtonSize: preset.shootButtonSize,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const playerProfiles = [
    {
      id: "agressivo",
      name: "Jogador Agressivo",
      desc: "Sensibilidade alta para movimentos rápidos",
      settings: {
        dpi: 520,
        sensitivity: 98,
        buttonSize: 42,
      },
    },
    {
      id: "equilibrado",
      name: "Jogador Equilibrado",
      desc: "Balanço entre velocidade e precisão",
      settings: {
        dpi: 450,
        sensitivity: 92,
        buttonSize: 48,
      },
    },
    {
      id: "defensivo",
      name: "Jogador Defensivo",
      desc: "Sensibilidade baixa para melhor controle",
      settings: {
        dpi: 380,
        sensitivity: 85,
        buttonSize: 52,
      },
    },
  ];

  const applyPlayerProfile = (profile: typeof playerProfiles[0]) => {
    setAndroidFunctions({ dpiValue: profile.settings.dpi });
    setInGameSettings({
      generalSensitivity: profile.settings.sensitivity,
      scope2xSensitivity: profile.settings.sensitivity,
      scope4xSensitivity: profile.settings.sensitivity - 3,
      shootButtonSize: profile.settings.buttonSize,
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Recomendações</Text>
          <Text className="text-sm text-muted mt-1">Personalizadas para seu dispositivo</Text>
        </View>

        {/* Dispositivo Detectado */}
        <View className="px-6 pt-6 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-3">
            Seu Dispositivo
          </Text>
          <View className="bg-surface rounded-lg p-4 border border-border">
            <View className="flex-row items-center gap-3 mb-3">
              <MaterialIcons name="phone-android" size={32} color={colors.primary} />
              <View className="flex-1">
                <Text className="text-base font-bold text-foreground">{deviceModel}</Text>
                <Text className="text-xs text-muted mt-1">
                  {preset ? preset.name : "Dispositivo genérico"}
                </Text>
              </View>
            </View>

            {preset && (
              <View className="mt-4 pt-4 border-t border-border gap-2">
                <View className="flex-row justify-between">
                  <Text className="text-sm text-muted">DPI Recomendado:</Text>
                  <Text className="text-sm font-bold text-primary">{preset.recommendedDPI}</Text>
                </View>
                <View className="flex-row justify-between">
                  <Text className="text-sm text-muted">Sensibilidade:</Text>
                  <Text className="text-sm font-bold text-primary">{preset.recommendedSensitivity}</Text>
                </View>
                <View className="flex-row justify-between">
                  <Text className="text-sm text-muted">Botão de Atirar:</Text>
                  <Text className="text-sm font-bold text-primary">{preset.shootButtonSize}%</Text>
                </View>
              </View>
            )}
          </View>
        </View>

        {/* Dicas do Dispositivo */}
        {preset && (
          <View className="px-6 pt-6 pb-2">
            <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-3">
              Dicas para {preset.name}
            </Text>
            <View className="gap-2">
              {preset.tips.map((tip, idx) => (
                <View
                  key={idx}
                  className="bg-surface rounded-lg p-3 border border-border flex-row gap-2"
                >
                  <Text className="text-lg">💡</Text>
                  <Text className="flex-1 text-xs text-muted">{tip}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Aplicar Preset do Dispositivo */}
        {preset && (
          <View className="px-6 pt-6 pb-2">
            <Pressable
              onPress={applyPreset}
              style={({ pressed }) => [
                {
                  backgroundColor: colors.success,
                  borderRadius: 12,
                  padding: 16,
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <Text className="text-base font-bold text-background text-center">
                ✓ Aplicar Configuração Recomendada
              </Text>
            </Pressable>
          </View>
        )}

        {/* Perfis de Jogador */}
        <View className="px-6 pt-8 pb-2">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Perfis de Jogador
          </Text>

          <View className="gap-3">
            {playerProfiles.map((profile) => (
              <Pressable
                key={profile.id}
                onPress={() => applyPlayerProfile(profile)}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.border,
                    borderWidth: 2,
                    borderRadius: 12,
                    padding: 16,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <View className="flex-row items-start justify-between mb-2">
                  <View className="flex-1">
                    <Text className="text-base font-bold text-foreground">
                      {profile.name}
                    </Text>
                    <Text className="text-xs text-muted mt-1">{profile.desc}</Text>
                  </View>
                  <MaterialIcons name="arrow-forward" size={20} color={colors.primary} />
                </View>

                <View className="mt-3 pt-3 border-t border-border flex-row justify-between text-xs">
                  <Text className="text-muted">
                    DPI: <Text className="font-bold text-primary">{profile.settings.dpi}</Text>
                  </Text>
                  <Text className="text-muted">
                    Sensi: <Text className="font-bold text-primary">{profile.settings.sensitivity}</Text>
                  </Text>
                  <Text className="text-muted">
                    Botão: <Text className="font-bold text-primary">{profile.settings.buttonSize}%</Text>
                  </Text>
                </View>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Dicas Gerais */}
        <View className="px-6 pt-8 pb-6">
          <Text className="text-xs font-semibold text-muted uppercase tracking-wider mb-4">
            Dicas de Ouro
          </Text>

          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View className="gap-2">
              <Text className="text-sm font-bold text-warning">🎯 Técnica do Puxadinho</Text>
              <Text className="text-xs text-muted leading-relaxed">
                Posicione a mira na altura do peito e puxe suavemente para cima até a cabeça. Pratique o timing!
              </Text>
            </View>

            <View className="gap-2 pt-3 border-t border-border">
              <Text className="text-sm font-bold text-warning">⚡ Control Shot</Text>
              <Text className="text-xs text-muted leading-relaxed">
                Use mira padrão (sem segurar o dedo) focando em movimentos rápidos. Melhor com botão esquerdo.
              </Text>
            </View>

            <View className="gap-2 pt-3 border-t border-border">
              <Text className="text-sm font-bold text-warning">🔧 Ajuste Gradual</Text>
              <Text className="text-xs text-muted leading-relaxed">
                Não mude tudo de uma vez. Ajuste DPI, depois sensibilidade, depois tamanho do botão.
              </Text>
            </View>

            <View className="gap-2 pt-3 border-t border-border">
              <Text className="text-sm font-bold text-warning">⏰ Prática Constante</Text>
              <Text className="text-xs text-muted leading-relaxed">
                A melhor função é a prática. Dedique tempo para treinar sua mira em partidas.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
