import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useMiraStore } from "@/lib/store";
import Slider from "@react-native-community/slider";
import { useState } from "react";
import * as Haptics from "expo-haptics";

type TabType = "geral" | "escopo" | "mira_vermelha" | "franco";

export default function SensibilidadeScreen() {
  const colors = useColors();
  const { sensibilidadeSettings, setSensibilidadeSettings } = useMiraStore();
  const [activeTab, setActiveTab] = useState<TabType>("geral");

  const tabs: { id: TabType; label: string }[] = [
    { id: "geral", label: "Geral" },
    { id: "escopo", label: "Escopo" },
    { id: "mira_vermelha", label: "Mira Vermelha" },
    { id: "franco", label: "Franco" },
  ];

  const handleSliderChange = (key: keyof typeof sensibilidadeSettings, value: number) => {
    setSensibilidadeSettings({ [key]: Math.round(value) });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "geral":
        return (
          <View className="gap-6">
            <SliderControl
              label="Sensibilidade Geral"
              value={sensibilidadeSettings.general}
              onChange={(v) => handleSliderChange("general", v)}
              colors={colors}
            />
            <SliderControl
              label="Sensibilidade de Mira"
              value={sensibilidadeSettings.aim}
              onChange={(v) => handleSliderChange("aim", v)}
              colors={colors}
            />
          </View>
        );
      case "escopo":
        return (
          <View className="gap-6">
            <SliderControl
              label="Escopo 2x"
              value={sensibilidadeSettings.scope2x}
              onChange={(v) => handleSliderChange("scope2x", v)}
              colors={colors}
            />
            <SliderControl
              label="Escopo 4x"
              value={sensibilidadeSettings.scope4x}
              onChange={(v) => handleSliderChange("scope4x", v)}
              colors={colors}
            />
            <SliderControl
              label="Escopo 8x"
              value={sensibilidadeSettings.scope8x}
              onChange={(v) => handleSliderChange("scope8x", v)}
              colors={colors}
            />
          </View>
        );
      case "mira_vermelha":
        return (
          <View className="gap-6">
            <SliderControl
              label="Mira Vermelha (Geral)"
              value={sensibilidadeSettings.general}
              onChange={(v) => handleSliderChange("general", v)}
              colors={colors}
            />
            <SliderControl
              label="Mira Vermelha (Mira)"
              value={sensibilidadeSettings.aim}
              onChange={(v) => handleSliderChange("aim", v)}
              colors={colors}
            />
          </View>
        );
      case "franco":
        return (
          <View className="gap-6">
            <SliderControl
              label="Franco-atirador (Geral)"
              value={sensibilidadeSettings.general}
              onChange={(v) => handleSliderChange("general", v)}
              colors={colors}
            />
            <SliderControl
              label="Franco-atirador (Escopo)"
              value={sensibilidadeSettings.scope8x}
              onChange={(v) => handleSliderChange("scope8x", v)}
              colors={colors}
            />
          </View>
        );
    }
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        {/* Header */}
        <View className="bg-surface px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-3xl font-bold text-primary">Sensibilidade</Text>
          <Text className="text-sm text-muted mt-1">Configure por arma ou modo</Text>
        </View>

        {/* Tabs */}
        <View className="px-6 pt-6 pb-4 flex-row gap-2">
          {tabs.map((tab) => (
            <Pressable
              key={tab.id}
              onPress={() => {
                setActiveTab(tab.id);
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              style={({ pressed }) => [
                {
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                  borderRadius: 8,
                  backgroundColor:
                    activeTab === tab.id ? colors.primary : colors.surface,
                  borderWidth: 1,
                  borderColor: activeTab === tab.id ? colors.primary : colors.border,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text
                className={`text-xs font-semibold ${
                  activeTab === tab.id ? "text-background" : "text-foreground"
                }`}
              >
                {tab.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Content */}
        <View className="px-6 pt-6 pb-6">{renderTabContent()}</View>

        {/* Save Button */}
        <View className="px-6 py-6">
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                borderRadius: 12,
                padding: 16,
                opacity: pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text className="text-base font-bold text-background text-center">
              Salvar Configuração
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

interface SliderControlProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  colors: any;
}

function SliderControl({ label, value, onChange, colors }: SliderControlProps) {
  return (
    <View>
      <View className="flex-row justify-between mb-2">
        <Text className="text-sm font-semibold text-foreground">{label}</Text>
        <Text className="text-sm font-bold text-primary">{value}</Text>
      </View>
      <Slider
        style={{ height: 40 }}
        minimumValue={1}
        maximumValue={100}
        step={1}
        value={value}
        onValueChange={onChange}
        minimumTrackTintColor={colors.primary}
        maximumTrackTintColor={colors.border}
        thumbTintColor={colors.primary}
      />
    </View>
  );
}
