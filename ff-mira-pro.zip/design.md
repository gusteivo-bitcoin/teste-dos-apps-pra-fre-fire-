# FF Mira Pro — Design Document (v2 - Reestruturado)

## Visão Geral

App Android profissional para otimizar mira e sensibilidade no Free Fire. Inclui configurações in-game simuladas, funções Android avançadas, assistências inteligentes e recomendações personalizadas por modelo de celular. **Sem modificação de arquivos do jogo** — apenas configurações locais.

---

## Paleta de Cores

| Token       | Valor (dark)  | Uso                            |
|-------------|---------------|--------------------------------|
| background  | #0A0A0F       | Fundo principal                |
| surface     | #13131A       | Cards e painéis                |
| primary     | #FF6B00       | Laranja FF — botões, destaques |
| accent      | #FFD700       | Amarelo neon — ícones ativos   |
| foreground  | #F0F0F0       | Texto principal                |
| muted       | #7A7A8A       | Texto secundário               |
| border      | #2A2A3A       | Bordas de cards                |
| error       | #FF3B30       | Erros e alertas                |
| success     | #30D158       | Confirmações                   |
| warning     | #FFD700       | Avisos                         |

---

## Estrutura de Telas (6 Abas)

### 1. Home
- Header com logo e versão
- Resumo rápido: Perfil ativo, sensibilidade geral, assistências ativas
- Cards com estatísticas (DPI recomendado, modelo do celular)
- Botões de acesso rápido para cada seção

### 2. Configurações In-Game
- **Ajuste Geral**: Slider 90-100
- **Mira 2x**: Slider 90-100
- **Mira 4x**: Slider 90-100
- **Tamanho Botão de Atirar**: Slider 40-55%
- **Posicionamento Botão**: Slider (vertical, ajuste)
- **Simulador Visual**: Preview mostrando o layout do botão na tela

### 3. Funções Android
- **DPI (Menor Largura)**: Slider com avisos de segurança
- **Velocidade do Ponteiro**: Slider 1-10
- **Tempo de Resposta ao Toque**: Dropdown (Longo/Normal/Curto)
- **Info do Dispositivo**: Exibir modelo, Android version, DPI atual
- **Aviso de Segurança**: "DPI muito alta pode formatar o celular"

### 4. Assistências Inteligentes
- **Grudar Mira na Cabeça**: Toggle + Slider (34%, 50%, 75%, 100%)
- **Gelo Rápido**: Toggle + Slider (intensidade 0-100)
- **Modo Armas**: Toggle + Seletor (AR, SMG, Shotgun, Sniper, Franco)
- **Control Shot**: Toggle + Dica de técnica
- Cada assistência com descrição e status (ativo/inativo)

### 5. Recomendações Personalizadas
- **Detecção de Modelo**: Exibir modelo do celular detectado
- **Sensibilidade Recomendada**: Baseada no modelo
- **DPI Recomendado**: Com range seguro
- **Dicas de Prática**: "Puxadinho", Control Shot, timing
- **Sugestões de Perfil**: Presets por tipo de jogador (Agressivo, Defensivo, Equilibrado)

### 6. Perfis (Existente)
- Manter funcionalidade anterior
- Adicionar opção de "Exportar/Importar" perfis

---

## Fluxos Principais

1. **Setup Inicial**: Home → Recomendações → Aplicar Preset → Salvar Perfil
2. **Otimizar In-Game**: Configurações In-Game → Ajustar Sliders → Simulador Visual → Salvar
3. **Ativar Assistências**: Assistências → Toggle Funções → Configurar Intensidade → Salvar
4. **Consultar Info**: Home → Card de Dispositivo → Funções Android → Ver Recomendações

---

## Dados Persistidos

```typescript
interface AdvancedSettings {
  // In-Game
  generalSensitivity: number; // 90-100
  scope2xSensitivity: number; // 90-100
  scope4xSensitivity: number; // 90-100
  shootButtonSize: number; // 40-55%
  shootButtonPosition: number; // 0-100 (vertical)

  // Android Functions
  dpiValue: number; // recomendado 350-600
  pointerSpeed: number; // 1-10
  touchResponseTime: "long" | "normal" | "short";

  // Assistências
  headstickEnabled: boolean;
  headstickStrength: number; // 34, 50, 75, 100
  iceQuickEnabled: boolean;
  iceQuickIntensity: number; // 0-100
  weaponModeEnabled: boolean;
  selectedWeapon: "ar" | "smg" | "shotgun" | "sniper" | "franco";
  controlShotEnabled: boolean;
}
```

---

## Navegação

6 abas na barra inferior:
- 🏠 Home
- ⚙️ In-Game
- 🔧 Android
- ✨ Assistências
- 💡 Recomendações
- 👤 Perfis

---

## Segurança & Compliance

- ✅ Sem modificação de arquivos do jogo
- ✅ Sem injeção de código
- ✅ Apenas configurações locais (AsyncStorage)
- ✅ Avisos claros sobre DPI e modificações do Android
- ✅ Nenhuma comunicação com servidores externos
