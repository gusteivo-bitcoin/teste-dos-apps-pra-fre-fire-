import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export interface MiraSettings {
  size: number;
  thickness: number;
  gap: number;
  color: string;
}

export interface SensibilitySettings {
  general: number;
  aim: number;
  scope2x: number;
  scope4x: number;
  scope8x: number;
}

export interface InGameSettings {
  generalSensitivity: number;
  scope2xSensitivity: number;
  scope4xSensitivity: number;
  shootButtonSize: number;
  shootButtonPosition: number;
}

export interface AndroidFunctions {
  dpiValue: number;
  pointerSpeed: number;
  touchResponseTime: "long" | "normal" | "short";
}

export interface SmartAssistances {
  headstickEnabled: boolean;
  headstickStrength: number;
  iceQuickEnabled: boolean;
  iceQuickIntensity: number;
  weaponModeEnabled: boolean;
  selectedWeapon: "ar" | "smg" | "shotgun" | "sniper" | "franco";
  controlShotEnabled: boolean;
}

export interface AccessibilitySettings {
  removeAnimations: boolean;
  animationScale: number;
  talkBackEnabled: boolean;
  switchAccessEnabled: boolean;
  longPressDelay: number;
  displaySize: number;
}

export interface PerformanceSettings {
  refreshRate: "60" | "90" | "120";
  gameTurboEnabled: boolean;
  disableAccidentalTouch: boolean;
  prioritizeGaming: boolean;
}

export interface HUDSettings {
  miraType: "novo" | "classico";
  visualEffect: "normal" | "sem-sangue" | "escuro";
  customCrosshairEnabled: boolean;
  crosshairSize: number;
  crosshairColor: string;
  crosshairOpacity: number;
}

export interface AccessoriesSettings {
  fingerSleevesRecommended: boolean;
  fingerSleevesType: "fibra-prata" | "algodao" | "nenhum";
  screenProtectorType: "vidro" | "plastico" | "nenhum";
  caseType: "fino" | "medio" | "nenhum";
}

export interface Profile {
  id: string;
  name: string;
  mira: MiraSettings;
  sensibilidade: SensibilitySettings;
  inGame: InGameSettings;
  android: AndroidFunctions;
  assistances: SmartAssistances;
  accessibility: AccessibilitySettings;
  performance: PerformanceSettings;
  hud: HUDSettings;
  accessories: AccessoriesSettings;
  createdAt: number;
}

interface MiraStore {
  miraSettings: MiraSettings;
  sensibilidadeSettings: SensibilitySettings;
  inGameSettings: InGameSettings;
  androidFunctions: AndroidFunctions;
  smartAssistances: SmartAssistances;
  accessibilitySettings: AccessibilitySettings;
  performanceSettings: PerformanceSettings;
  hudSettings: HUDSettings;
  accessoriesSettings: AccessoriesSettings;
  activeProfile: string | null;
  profiles: Profile[];

  setMiraSettings: (settings: Partial<MiraSettings>) => void;
  setSensibilidadeSettings: (settings: Partial<SensibilitySettings>) => void;
  setInGameSettings: (settings: Partial<InGameSettings>) => void;
  setAndroidFunctions: (settings: Partial<AndroidFunctions>) => void;
  setSmartAssistances: (settings: Partial<SmartAssistances>) => void;
  setAccessibilitySettings: (settings: Partial<AccessibilitySettings>) => void;
  setPerformanceSettings: (settings: Partial<PerformanceSettings>) => void;
  setHUDSettings: (settings: Partial<HUDSettings>) => void;
  setAccessoriesSettings: (settings: Partial<AccessoriesSettings>) => void;

  setActiveProfile: (profileId: string | null) => void;
  createProfile: (name: string) => void;
  loadProfile: (profileId: string) => void;
  deleteProfile: (profileId: string) => void;
  updateProfile: (profileId: string, name: string) => void;
}

const defaultMiraSettings: MiraSettings = {
  size: 5,
  thickness: 2,
  gap: 3,
  color: "#FF6B00",
};

const defaultSensibilidadeSettings: SensibilitySettings = {
  general: 50,
  aim: 40,
  scope2x: 35,
  scope4x: 30,
  scope8x: 25,
};

const defaultInGameSettings: InGameSettings = {
  generalSensitivity: 95,
  scope2xSensitivity: 95,
  scope4xSensitivity: 90,
  shootButtonSize: 50,
  shootButtonPosition: 50,
};

const defaultAndroidFunctions: AndroidFunctions = {
  dpiValue: 450,
  pointerSpeed: 5,
  touchResponseTime: "normal",
};

const defaultSmartAssistances: SmartAssistances = {
  headstickEnabled: false,
  headstickStrength: 50,
  iceQuickEnabled: false,
  iceQuickIntensity: 50,
  weaponModeEnabled: false,
  selectedWeapon: "ar",
  controlShotEnabled: false,
};

const defaultAccessibilitySettings: AccessibilitySettings = {
  removeAnimations: true,
  animationScale: 0,
  talkBackEnabled: false,
  switchAccessEnabled: false,
  longPressDelay: 0.5,
  displaySize: 100,
};

const defaultPerformanceSettings: PerformanceSettings = {
  refreshRate: "90",
  gameTurboEnabled: true,
  disableAccidentalTouch: true,
  prioritizeGaming: true,
};

const defaultHUDSettings: HUDSettings = {
  miraType: "novo",
  visualEffect: "sem-sangue",
  customCrosshairEnabled: true,
  crosshairSize: 15,
  crosshairColor: "#FFD700",
  crosshairOpacity: 80,
};

const defaultAccessoriesSettings: AccessoriesSettings = {
  fingerSleevesRecommended: true,
  fingerSleevesType: "fibra-prata",
  screenProtectorType: "vidro",
  caseType: "fino",
};

export const useMiraStore = create<MiraStore>()(
  persist(
    (set) => ({
      miraSettings: defaultMiraSettings,
      sensibilidadeSettings: defaultSensibilidadeSettings,
      inGameSettings: defaultInGameSettings,
      androidFunctions: defaultAndroidFunctions,
      smartAssistances: defaultSmartAssistances,
      accessibilitySettings: defaultAccessibilitySettings,
      performanceSettings: defaultPerformanceSettings,
      hudSettings: defaultHUDSettings,
      accessoriesSettings: defaultAccessoriesSettings,
      activeProfile: null,
      profiles: [],

      setMiraSettings: (settings) =>
        set((state: MiraStore) => ({
          miraSettings: { ...state.miraSettings, ...settings },
        })),

      setSensibilidadeSettings: (settings) =>
        set((state: MiraStore) => ({
          sensibilidadeSettings: { ...state.sensibilidadeSettings, ...settings },
        })),

      setInGameSettings: (settings) =>
        set((state: MiraStore) => ({
          inGameSettings: { ...state.inGameSettings, ...settings },
        })),

      setAndroidFunctions: (settings) =>
        set((state: MiraStore) => ({
          androidFunctions: { ...state.androidFunctions, ...settings },
        })),

      setSmartAssistances: (settings) =>
        set((state: MiraStore) => ({
          smartAssistances: { ...state.smartAssistances, ...settings },
        })),

      setAccessibilitySettings: (settings) =>
        set((state: MiraStore) => ({
          accessibilitySettings: { ...state.accessibilitySettings, ...settings },
        })),

      setPerformanceSettings: (settings) =>
        set((state: MiraStore) => ({
          performanceSettings: { ...state.performanceSettings, ...settings },
        })),

      setHUDSettings: (settings) =>
        set((state: MiraStore) => ({
          hudSettings: { ...state.hudSettings, ...settings },
        })),

      setAccessoriesSettings: (settings) =>
        set((state: MiraStore) => ({
          accessoriesSettings: { ...state.accessoriesSettings, ...settings },
        })),

      setActiveProfile: (profileId) => set({ activeProfile: profileId }),

      createProfile: (name) =>
        set((state: MiraStore) => {
          const newProfile: Profile = {
            id: Date.now().toString(),
            name,
            mira: { ...state.miraSettings },
            sensibilidade: { ...state.sensibilidadeSettings },
            inGame: { ...state.inGameSettings },
            android: { ...state.androidFunctions },
            assistances: { ...state.smartAssistances },
            accessibility: { ...state.accessibilitySettings },
            performance: { ...state.performanceSettings },
            hud: { ...state.hudSettings },
            accessories: { ...state.accessoriesSettings },
            createdAt: Date.now(),
          };
          return {
            profiles: [...state.profiles, newProfile],
            activeProfile: newProfile.id,
          };
        }),

      loadProfile: (profileId) =>
        set((state: MiraStore) => {
          const profile = state.profiles.find((p: Profile) => p.id === profileId);
          if (profile) {
            return {
              miraSettings: { ...profile.mira },
              sensibilidadeSettings: { ...profile.sensibilidade },
              inGameSettings: { ...profile.inGame },
              androidFunctions: { ...profile.android },
              smartAssistances: { ...profile.assistances },
              accessibilitySettings: { ...profile.accessibility },
              performanceSettings: { ...profile.performance },
              hudSettings: { ...profile.hud },
              accessoriesSettings: { ...profile.accessories },
              activeProfile: profileId,
            };
          }
          return state;
        }),

      deleteProfile: (profileId) =>
        set((state: MiraStore) => ({
          profiles: state.profiles.filter((p: Profile) => p.id !== profileId),
          activeProfile: state.activeProfile === profileId ? null : state.activeProfile,
        })),

      updateProfile: (profileId, name) =>
        set((state: MiraStore) => ({
          profiles: state.profiles.map((p: Profile) =>
            p.id === profileId ? { ...p, name } : p
          ),
        })),
    }),
    {
      name: "mira-storage",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
