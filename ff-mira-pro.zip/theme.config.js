/** @type {const} */
const themeColors = {
  primary: { light: '#FF6B00', dark: '#FF6B00' },
  background: { light: '#0A0A0F', dark: '#0A0A0F' },
  surface: { light: '#13131A', dark: '#13131A' },
  foreground: { light: '#F0F0F0', dark: '#F0F0F0' },
  muted: { light: '#7A7A8A', dark: '#7A7A8A' },
  border: { light: '#2A2A3A', dark: '#2A2A3A' },
  success: { light: '#30D158', dark: '#30D158' },
  warning: { light: '#FFD700', dark: '#FFD700' },
  error: { light: '#FF3B30', dark: '#FF3B30' },
  accent: { light: '#FFD700', dark: '#FFD700' },
};

module.exports = { themeColors };
